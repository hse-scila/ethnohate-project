RuEthnoHateExtended

Extended version of RuEthnoHate including texts and instances with annotators' disagreements.



Corpus volume:

texts: 12339
"text + ethnic group" instances: 33059

(*The initial collection consisted of 14998 texts out of which duplicates and instances marked by unreliable annotators were removed)



Keys:

text_id					- unique identifier for texts
ethnic_group			- target ethnic group
instance_id				- unique identifier for (text, ethnic group) pairs
text					- source text
class					- attitude towards ethnic group
assessor				- unique identifier for assessors			
does_text_make_sense	- a binary variable to cut off texts that are not subject to further analysis
text_has_ethnonyms		- a variable to cut off texts without ethnic groups


Values:

class

-1		- negative
0		- neutral
1		- positive
''		- NaN
'unk'	- unknown


does_text_make_sense

'yes'	- text makes sense, is subject to further analysis
'no'	- text does not make sense, is not subject to further analysis (is a quotation / a joke / is not in Russian / etc. )


text_has_ethnonyms

''		- NaN
'no'	- text does not contain ethnonyms
'yes'	- text contains ethnonyms
'unk'	- it is unknown whether text contains ethnonyms


The corpus was collected as part of the research project "Ethnic Hate Speech Prediction in Social Media Texts" at the Laboratory for Social and Cognitive Informatics of the National Research University Higher School of Economics in Russia in 2020.