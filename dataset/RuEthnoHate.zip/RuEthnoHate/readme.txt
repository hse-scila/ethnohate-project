RuEthnoHate

The first dataset annotated with ethnicity-targeted hate speech in Russian


Statistics:

texts: 5594
"text + ethnic group" instances: 12052


Keys:

text_id					- unique identifier for texts
ethnic_group			- target ethnic group
instance_id				- unique identifier for (text, ethnic group) pairs
text					- source text
class					- attitude towards ethnic group


Values:

class

-1	- negative
0	- neutral
1	- positive


The corpus was collected as part of the research project "Ethnic Hate Speech Prediction in Social Media Texts" at the Laboratory for Social and Cognitive Informatics of the National Research University Higher School of Economics in Russia in 2020.